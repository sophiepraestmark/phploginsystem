<?php 
// Nedenfor bliver der ledt efter om POST-array findes, og om der er blevet trykket submit !
if(isset($_POST['submit'])){
// Nedenfor oprettes forbindelse til databsen !
$connection = new MySQLi(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);

// Sprog specifikationer for dansk defineres!
$connection->set_charset("utf8");

// hvis forbindelse fejler skal den "Dø" (der skal ikke ske noget)! Hvis ikke (Else) skal der vises linjen inden i echo (h1 tekst)i browseren!
if($connection->connect_error){
	die($connection->connect_error);
} else {
	echo '<h1>Succesful connection to MySQL server!</h1>';
}
// Nedenfor bliver der hentet forskellig POST array data for de forskellige felter der skal udfyldes for at lave en ny bruger!!! Samtidigt sikres der mod SQL injection, så andre brugere ikke kan ændre i ens kode og ødelægge funktioner, skabe nye funktioner eller lignende!
$name = mysqli_real_escape_string ($connection, $_POST['name']);
$email = mysqli_real_escape_string ($connection, $_POST['email']);
$password = mysqli_real_escape_string ($connection, $_POST['password']);

// Nedenfor startes en ny query som gør det muligt at uploade og se billedet!
$sqlUpdate = "INSERT INTO phploginsystem (name, email, password) VALUES ('$name', '$email', '$password')";

// Neden for udføres min query, og brugeren vil få en af de to meddeelser frem på skærmen, alt efter om det lykkedes eller ej at lave en ny user!!! 
if(mysqli_query($connection, $sqlUpdate)){
	echo 'Welcome!';
} else {
	echo 'Something went wrong!';
}
///Nedenfor lukkes forbindelsen!
mysqli_close($connection);

}
?>