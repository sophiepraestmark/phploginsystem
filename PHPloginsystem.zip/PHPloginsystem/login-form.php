<link rel="stylesheet" href="style.css"><!--Her linkes til mit eksterne stylesheet-->
<?php
// Denne linje starter sessionen!
session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Please login or register</title>

</head>

<body>

 <a href="secret.php">Login to see the secret site!</a>  or  <a href="create-user-form.php">Create New User</a><br><br><br>


<!--Selve formen som skal udfyldes af brugeren for at logge ind!-->
<form method="post" action="login.php">
 Name:<br>
 <input type="text" name="name" required /><br><br>
 Password:<br>
 <input type="password" name="password" required /> <br><br>
 
 <input type="submit" value="login"/><br><br>
 </form>
 


</body>
</html>