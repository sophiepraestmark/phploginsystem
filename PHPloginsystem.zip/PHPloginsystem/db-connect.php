<?php

// Denne fil forbinder til den bagvedliggende database! Her er det vigtigt at definere de korrekte informationer for ens database, så der kan oprettes forbindelse!

define("HOSTNAME", "localhost");
define("MYSQLUSER", "Login01");
define("MYSQLPASS", "1234");
define("MYSQLDB", "PHPloginsystem");

$connection = new MySQLi(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);

if($connection->connect_error){
die($connection->connect_error);
} else {

}
?>

