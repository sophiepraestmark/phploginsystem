<link rel="stylesheet" href="style.css">

<?php
// Denne linje starter sessionen!
session_start();

// Her fjernes alle session variabler.
$_SESSION = array();

// nedenfor slettes sessionens data  (session cookie slettes så der intet data er tilbage når der logges ud!!!)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Nedenunder slettes sessionen - og brugeren er logget ud!
session_destroy();
?>You are now logged out