<?php
// Denne linje starter sessionen!
session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Register below</title>

<link rel="stylesheet" href="style.css">

</head>

<body>

<a href="create-user-form.php">Create New User!</a> or <a href="login-form.php">Login to see the secret site</a> <br><br><br>  

<!--Selve formen som skal udfyldes af brugeren for at lave en ny bruger!-->
<form method="post" action="create-user.php">
  Name:<br>
  <input type="text" name="name" required><br><br>
   Email:<br>
  <input type="text" name="email" required><br><br>
  Password:<br>
  <input type="text" name="password"required>
   <br><br>
   <input type="submit" value="submit" name="submit">
</form>

</body>
</html>