-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 29. 09 2016 kl. 14:29:11
-- Serverversion: 10.1.10-MariaDB
-- PHP-version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `PHPloginsystem`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `phploginsystem`
--

CREATE TABLE `phploginsystem` (
  `id` int(2) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `phploginsystem`
--

INSERT INTO `phploginsystem` (`id`, `name`, `email`, `password`) VALUES
(1, 'Poul', 'p@sddssd.dk', '123'),
(2, 'nweohfgoer', 'nweohfo@newui.dk', '$2y$10$r5IrEjec3gBGE8qhA1JInOqJHFlnrlIUUEUaXj2SuRU'),
(3, 'bjbifw', 'nwe@nei.dk', '$2y$10$cOfWuhS/ImB93X27v3ILIutg8mtOfuIQCcdusNIoES8'),
(4, 'nkf', 'fwnep@jfwi.dk', '$2y$10$L/mtNxPVJ7S6ck27AYtmTOrKygx/ppVnORIA4RmvQmF'),
(5, 'lise', 'lise@nqjw.dk', '$2y$10$OLzBEUKj4KoAa8gmtOibKu6V0aDYQ4jwdDLsxFZGq/9qU1NE.nH6.');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `phploginsystem`
--
ALTER TABLE `phploginsystem`
  ADD PRIMARY KEY (`id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `phploginsystem`
--
ALTER TABLE `phploginsystem`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
