<?php

session_start();

// Nedenfor bruger jeg filter_input til at indhente de data der indtastes i min create-user form!
// Derudover laver jeg password validation ved at oprette et hash for mit password, så brugerens login informationer ikke er tilgængelige for andre og f.eks. ikke kan findes i stien i browseren!!!

$name = filter_input(INPUT_POST, 'name') or die('not valid name!');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL) or die('not valid email');
$password = filter_input(INPUT_POST, 'password') or die('not valid password');
$phash = password_hash($password, PASSWORD_DEFAULT);

echo $name;
echo $email;
echo $phash;


require_once 'db-connect.php';

// Her indsættes de indtastede værdier i de korrekte tabeller !
$sql = 'INSERT INTO phploginsystem (name, email, password) VALUES (?,?,?)';

// Her oprettes en forbindelse !
$stmt = $connection->prepare($sql);
// Her forbindes variablerne i det statement som blev defineret ovenfor, indeholdende prepare($sql) !
$stmt->bind_param('sss', $name, $email, $phash);
// og så udføres denne forespørgsel (brugeren bliver oprettet!)
$stmt->execute();


?>

