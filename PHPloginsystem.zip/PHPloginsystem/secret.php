<link rel="stylesheet" href="style.css">

<?php
//Her startes sessionen
session_start();
//her oprettes forbindelse til databasen!
include('db-connect.php');
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>

<?php

// Nedenfor bruger jeg "if condition" til at hente brugerens id, og herved tjekke om brugeren er logget in eller ej! Hvis tilstanden er rigtig, vises den hemmelige side - hvis ikke vil der stå "no info without login" - i korte træk : findes bruger id'et i sessionen?

if (isset($_SESSION['uid'])){
	
	echo 'Sophie Præstmark is the best!!!<br><br><br>';
	echo '<a href="logout.php">Logout</a>';
	
} else {
		echo 'no info without login';
		
	}

?>
</body>
</html>