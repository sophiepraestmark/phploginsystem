<link rel="stylesheet" href="style.css">

<?php
// sesseionen startes
session_start();
// der oprettes forbindelse til databasen
require_once('db-connect.php');

// Her bruger jeg filter_input til at kontrollere det der bliver udfyldt i formens felter !!
$name = filter_input(INPUT_POST, 'name') or die ('wrong!');
$password = filter_input(INPUT_POST, 'password') or die ('wrong!');


// Her har jeg anvendt et prepared staement til at læse alle data fra min "phploginsystem" tabel, og brugt PHP til at udvinde al data fra denne, i en HTML tabel!
    $sql = "SELECT id, name, password FROM phploginsystem WHERE name=?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $stmt->bind_result($id, $name, $phash);
    if($stmt->fetch()){		
	
	
// Hvis kodeordet er valideret, vil forbrugeren blive logget ind, og kan ved brug af gobal variablen $_SESSION (som anvender brugerens id til at tjekke om brugeren har tilladelse) komme ind på den hemmelige side !!!
		if(password_verify($password, $phash)){
			echo 'login succes<br><br><br>';
			
			$_SESSION['uid'] = $id;
			
			echo '<a href="secret.php">Enter secret site</a>';
			
// Hvis dette ikke virker, og dataen der er indtastet i felterne ikke kan valideres/hentes, vil brugeren blive nægtet adgang!			
		} else{
			echo 'login failed<br><br><br>';
			
			echo '<a href="login-form.php">Try again!</a>';
		
		}
    }
	else { 
			echo 'øv';
	}
?>


